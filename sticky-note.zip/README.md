# sticky-note
This is a one page sticky created by @seunzone
Do holla if you wanna contribute or improve this repo...Thanks
